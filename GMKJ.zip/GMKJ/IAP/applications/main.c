/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2015-07-29     Arda.Fu      first implementation
 */
#include <stdint.h>
#include <rtthread.h>
#include <rtdevice.h>
#include <dfs_posix.h>
#include <ulog.h>

/* defined the LED1 pin: PB5 */
#define LED1_PIN    57
#define IAP_UART       "uart2"

static void mkdir_IAPFile(void);

int main(void)
{
    uint32_t Speed = 200;
    /* set LED1 pin mode to output */
    rt_pin_mode(LED1_PIN, PIN_MODE_OUTPUT);

    mkdir_IAPFile();

    while (1)
    {
        rt_pin_write(LED1_PIN, PIN_LOW);
        rt_thread_mdelay(Speed);
        rt_pin_write(LED1_PIN, PIN_HIGH);
        rt_thread_mdelay(Speed);
    }
}

static void mkdir_IAPFile(void)
{
    int ret;

    /* ����Ŀ¼ */
    ret = mkdir("/IAPFile", 0x777);
    if (ret < 0)
    {
        /* ����Ŀ¼ʧ�� */
        rt_kprintf("dir error!\n");
    }
    else
    {
        /* ����Ŀ¼�ɹ� */
        rt_kprintf("mkdir ok!\n");
    }
}
