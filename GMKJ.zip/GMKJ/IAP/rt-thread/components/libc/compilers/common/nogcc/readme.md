## Attentions

This folder is "common" for toolchains excluding gcc.